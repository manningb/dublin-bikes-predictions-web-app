import os

DB_PASS=os.environ("DB_PASS")
DB_URI=os.environ("DB_URI")
DB_PORT=os.environ("DB_PORT")
DB_DB=os.environ("DB_DB") 
DB_USER=os.environ("DB_USER")
APIKEY=os.environ("APIKEY")